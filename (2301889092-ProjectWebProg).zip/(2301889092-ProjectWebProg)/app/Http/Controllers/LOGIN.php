<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use 


class LOGIN extends Controller
{
    //
    public function index
}
